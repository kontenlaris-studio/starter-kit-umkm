# Template Spreadsheet UMKM — panduan singkat

5 file CSV — buka dengan Google Sheets / Excel / LibreOffice, semua rumus dasar tinggal ditambah:

1. **01-buku-kas-harian.csv** — catat semua uang masuk/keluar. Saldo = saldo sebelumnya + masuk − keluar (tarik rumus ke bawah).
2. **02-stok-inventaris.csv** — Stok Akhir = Stok Awal + Masuk − Keluar. Kolom Status: tandai "SEGERA RESTOK" bila Stok Akhir < Stok Minimum.
3. **03-daftar-harga.csv** — Harga Jual = Harga Modal × (1 + Markup%). Satu sumber kebenaran harga untuk semua channel.
4. **04-rekap-penjualan-bulanan.csv** — satu baris per transaksi; buat PivotTable per Produk & per Channel untuk tahu yang paling laris.
5. **05-piutang-jatuh-tempo.csv** — Sisa = Total Utang − Sudah Dibayar. Pasangkan dengan workflow pengingat bayar di folder 02 untuk menagih otomatis via WhatsApp.

Contoh baris di setiap file boleh dihapus — itu hanya contoh format.
