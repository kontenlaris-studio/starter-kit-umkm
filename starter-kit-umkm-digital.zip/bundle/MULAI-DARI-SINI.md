# Starter Kit UMKM Digital — Kontenlaris Studio

Tiga alat yang saling mengunci untuk menjalankan toko kecil secara digital:

## 01 — InvoiceKit (offline)
`01-invoicekit-offline/invoicekit.html` — buka di browser, tanpa internet, tanpa akun. Buat invoice profesional: logo usaha, banyak invoice tersimpan, nomor otomatis, stempel LUNAS, ekspor/impor data. Semua data tersimpan di browser kamu sendiri.

## 02 — Workflow n8n (otomatisasi)
`02-workflow-n8n/` — 4 workflow siap impor ke n8n: catat order otomatis, pengingat bayar, rekap penjualan harian, balas lead otomatis. Ikuti `PANDUAN.md` di dalamnya (Bahasa Indonesia, langkah demi langkah).

## 03 — Template Spreadsheet
`03-template-spreadsheet/` — buku kas, stok, daftar harga, rekap penjualan, piutang. Baca `PANDUAN.md`-nya untuk rumus & cara pakai.

## Urutan mulai yang disarankan (1 minggu)
- Hari 1: isi daftar harga (template 03) — ini fondasi semuanya.
- Hari 2: buat invoice pertamamu di InvoiceKit untuk order berikutnya.
- Hari 3–4: pasang n8n + workflow catat order & rekap harian.
- Hari 5: aktifkan pengingat bayar; masukkan piutang yang masih berjalan.
- Seterusnya: kas & stok tercatat sendiri; kamu cukup cek rekap harian.

Dukungan: kontenlaris.studio@gmail.com
